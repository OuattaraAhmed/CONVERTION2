<html>
<head>
<title>Convertir image en text</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<center>
<h3>Convertion d'image en text</h3>
<form action="upload.php" method="POST" enctype="multipart/form-data">
<input type="file" name="image" />
<input type="submit"/>
</form>
</center>

</body>